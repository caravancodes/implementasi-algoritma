package modul8;
import java.util.Scanner;
class PanggilMhs {

    static class Mahasiswa{
        String nama;
        String nip;
        int jam,menit,detik,jam1,menit1,detik1,jam2,menit2,detik2,total1,total2,jumlah;
    }

    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);

        Mahasiswa mhs = new Mahasiswa();
        System.out.println("==============================");
        System.out.println("PROGRAM DATA KARYAWAN");
        System.out.println("==============================");
        System.out.print("Nama Karyawan       : ");
        mhs.nama = sc.next();
        System.out.print("NIP                 : ");
        mhs.nip = sc.next();
        System.out.println("");
        System.out.println("Input Waktu Datang ");
        System.out.print("Jam : ");
        mhs.jam1 = sc.nextInt();
        System.out.print("Menit : ");
        mhs.menit1 = sc.nextInt();
        System.out.print("Detik : ");
        mhs.detik1 = sc.nextInt();
        mhs.total1 = (mhs.jam1 * 3600 + mhs.menit1*60 + mhs.detik1);
        System.out.println("Input Waktu Pulang ");
        System.out.print("Jam : ");
        mhs.jam2 = sc.nextInt();
        System.out.print("Menit : ");
        mhs.menit2 = sc.nextInt();
        System.out.print("Detik : ");
        mhs.detik2 = sc.nextInt();
        mhs.total2 = (mhs.jam2 * 3600 + mhs.menit2*60 + mhs.detik2);

        mhs.jumlah = mhs.total2 - mhs.total1;
        mhs.jam = mhs.jumlah / 3600;
        mhs.menit = mhs.jumlah % 3600 / 60;
        mhs.detik = mhs.jumlah % 3600 % 60;
        System.out.println("Pekerja dengan nama: "+ mhs.nama + ", Dengan NIP: " + mhs.nip);
        System.out.println("Memiliki lama kerja: "+ mhs.jam + " jam " + mhs.menit+" menit " + mhs.detik +" detik");


    }
}


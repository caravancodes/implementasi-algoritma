package modul8;

public class Main {

    public static void main(String[] args) {
        System.out.println("==============================");
        System.out.println("PROGRAM PENGECEK 2 BUAH KATA");
        System.out.println("==============================");
        System.out.println("Nama    : Silfi Nur Amalia");
        System.out.println("NIM     : 6706160043");
        System.out.println("Kelas   : D3IF-40-01");
        System.out.println("________________________________");
        System.out.println("Masukkan kata pertama : ");

        System.out.println("Masukkan kata kedua : ");

    }
}

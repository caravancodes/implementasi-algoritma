package modul8;

import java.util.Scanner;

class PanggilMhs {

    static class Mahasiswa{
        String nomor;

    public void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Mahasiswa mhs = new Mahasiswa();
        System.out.println("==============================");
        System.out.println("PROGRAM PERUBAH FORMAT NO.HP");
        System.out.println("==============================");
        System.out.println("Nama    : Silfi Nur Amalia");
        System.out.println("NIM     : 6706160043");
        System.out.println("Kelas   : D3IF-40-01");
        System.out.println("________________________________");
        System.out.print("Masukkan Nomor Handphone : ");
        mhs.nomor = sc.next();
        StringBuilder sb = new StringBuilder(mhs.nomor);
        sb.delete(1, 3);
        System.out.println(sb);
        sb.append(+62);
        System.out.println(sb);
        System.out.println("==============================");
        System.out.println("PROGRAM PERUBAH FORMAT NO.HP");
        System.out.println("==============================");
        System.out.println("Nama    : Silfi Nur Amalia");
        System.out.println("NIM     : 6706160043");
        System.out.println("Kelas   : D3IF-40-01");
        System.out.println("________________________________");

    }
    }
}

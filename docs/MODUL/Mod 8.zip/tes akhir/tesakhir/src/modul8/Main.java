package modul8;

import java.util.Scanner;

public class Mahasiswa {

    public static void main(String[] args) {
        String judul;

        Scanner sc = new Scanner (System.in);
        Mahasiswa mhs = new Mahasiswa;
        System.out.print("masukkan Judul    : ");
        mhs.judul = sc.next();
        System.out.print("Masukkan Penulis  : ");
        mhs.penulis = sc.next();
        System.out.print("Masukkan Penerbit : ");
        mhs.penerbit = sc.next();
        System.out.print("Masukkan Harga    : ");
        System.out.print("Masukkan Tahun Terbit : ");
    }
}

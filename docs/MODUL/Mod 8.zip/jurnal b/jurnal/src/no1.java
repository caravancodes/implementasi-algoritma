import java.util.Scanner;

/**
 * Created by PRAKTIKUM on 10/17/2016.
 */
public class no1 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String kata;
        boolean kalimat = true;
        System.out.println("==========================");
        System.out.println("Nama  : Danah Miftafarid");
        System.out.println("Kelas : D3IF-40-01");
        System.out.println("NIM   : 6706160049");
        System.out.println("===========================");
        System.out.print("Masukkan kata\t: ");
        kata = scn.next();
        int y = (kata.length() - 1);
        int k = y;
        int j = y;
        for (int i = 0; i < y; i++) {
            if (kata.charAt(i) != kata.charAt(k))
                kalimat = false;
            break;
        }
        for (int i = y; i >=0 ; i--) {
        }
        System.out.println("Hasil Inverse : "+kata);
        System.out.println();
        if (kalimat) {
            System.out.println(kata+" sama dengan "+kata);
            System.out.println(kata+" merupakan palindrame");
        } else {
            System.out.println(kata+" tidak sama dengan "+kata);
            System.out.println(kata+" bukan palindrame");
        }
    }
}


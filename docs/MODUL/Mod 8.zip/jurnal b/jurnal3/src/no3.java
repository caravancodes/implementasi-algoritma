import java.util.Scanner;

/**
 * Created by PRAKTIKUM on 10/17/2016.
 */
public class no3 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int banyak;
        System.out.println("=====================================");
        System.out.println(" PROGRAM PERHITUNGAN STATISTIK KATA ");
        System.out.println("=====================================");
        System.out.println("Nama  : Danah Miftafarid");
        System.out.println("NIM   : 6706160049");
        System.out.println("Kelas : D3IF-40-01");
        System.out.println("=====================================");
        System.out.print("Masukkan banyak kata yang ingin diinputkan : ");
        banyak = scn.nextInt();
        String kata[] = new String[banyak];
        for (int i = 0; i < banyak ; i++) {
            System.out.print("Masukkan kata ke-"+(i+1)+" : ");
            kata[banyak] = scn.next();
        }
        System.out.println("STATISTIK KATA : ");
        System.out.println("________________________________");
    }
}

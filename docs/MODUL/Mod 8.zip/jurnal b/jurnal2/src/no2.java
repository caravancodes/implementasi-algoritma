import java.util.Scanner;

/**
 * Created by PRAKTIKUM on 10/17/2016.
 */
public class no2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int pilih;
        System.out.println("==========================");
        System.out.println("        TOKO BUKU         ");
        System.out.println("==========================");
        System.out.println("Menu : ");
        System.out.println("1. Masukkan Data");
        System.out.println("2. Lakukan Pembelian");
        System.out.println("3. Exit");
        System.out.print("Pilihan : ");
        pilih = scn.nextInt();
    }
}
